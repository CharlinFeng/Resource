//
//  NSDictionary+Sqlite.h
//  CoreClass
//
//  Created by 冯成林 on 15/5/28.
//  Copyright (c) 2015年 muxi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Sqlite)

@property (nonatomic,copy,readonly) NSString *sqlWhere;


@end
