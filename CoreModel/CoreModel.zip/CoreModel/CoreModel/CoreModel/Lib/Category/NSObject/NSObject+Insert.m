//
//  NSObject+Insert.m
//  BaseModel
//
//  Created by muxi on 15/3/30.
//  Copyright (c) 2015年 muxi. All rights reserved.
//

#import "NSObject+Insert.h"
#import "BaseModel.h"
#import "MJProperty.h"
#import "MJType.h"
#import "NSObject+BaseModelCommon.h"
#import "BaseMoelConst.h"
#import "CoreFMDB.h"
#import "NSObject+Select.h"
#import "NSArray+CoreModel.h"

@implementation NSObject (Insert)


+(void)insertAction:(id)model resBlock:(void(^)(BOOL res))resBlock {
    
    [self checkUsage:model];
    
    if(![self checkTableExists]){
        
        if(BaseModelDeBug) NSLog(@"注意：单条数据插入时，你操作的模型%@在数据库中没有对应的数据表！%@",[self modelName],AutoMsg);
      
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(AutoTry * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self insertAction:model resBlock:resBlock];
        });
        
        return;
    }

    if(![model isKindOfClass:[self class]]){
        if(BaseModelDeBug) NSLog(@"错误：插入数据请使用%@模型类对象，您使用的是%@类型",[self modelName],[model class]);
        if(resBlock != nil) resBlock(NO);return;
    }
    
    BaseModel *baseModel=(BaseModel *)model;

    if(baseModel.hostID==0){
        if(BaseModelDeBug) NSLog(@"错误：数据插入失败,无hostID的数据插入都是耍流氓，你必须设置模型的模型hostID!");
        if(resBlock != nil) resBlock(NO);return;
    }
    if(BaseModelDeBug)  NSLog(@"数据插入开始%@",[NSThread currentThread]);

    [self find:baseModel.hostID selectResultBlock:^(id dbModel) {
        
        if(dbModel!=nil){
            if(BaseModelDeBug) NSLog(@"%@的数据已经存在",@(baseModel.hostID));
            if(resBlock != nil) resBlock(NO);return;
        }
        
        NSMutableString *fields=[NSMutableString string];
        NSMutableString *values=[NSMutableString string];
        
        [self enumerateProperties:^(MJProperty *property, BOOL *stop) {
            
            BOOL skip=[self skipField:property];
            
            if(!skip){
                
                NSString *sqliteTye=[self sqliteType:property.type.code];
   
                id value =[model valueForKeyPath:property.name];
                
                if([property.type.code isEqualToString:CoreNSArray]){
                    
                    if([self isBasicTypeInNSArray:[self statementForNSArrayProperties][property.name]]){
                        sqliteTye = TEXT_TYPE;
                    }
                }
                
                if(![sqliteTye isEqualToString:EmptyString]){
                    
                    [fields appendFormat:@"%@,",property.name];
                    
                    if([property.type.code isEqualToString:CoreNSString]){
                        
                        if(value == nil) value=@"";
                        
                        value=[NSString stringWithFormat:@"'%@'",value];
                        
                    }else if ([property.type.code isEqualToString:CoreNSData]){
                        
                        if(value == nil) value=@"";
                        
                        value =[NSString stringWithFormat:@"'%@'",[(NSData *)value base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength]];
                        
                    }
                    
                    if([property.type.code isEqualToString:CoreNSArray]){
                        
                        
                        if([self isBasicTypeInNSArray:[self statementForNSArrayProperties][property.name]]){
                            
                            NSString *valueStr = nil;
                            
                            if(value == nil){
                                valueStr = @"";
                            }else{
                                valueStr = ((NSArray *)value).toString;
                            }
                            
                            value = [NSString stringWithFormat:@"'%@'",valueStr];
                        }
                    }
                    
                    if(value != nil) {
                        [values appendFormat:@"%@,",value];
                    }
                    
                }else{
                    
                    if(property.name!=nil && value!=nil){
                        
                        
                        if(![property.type.code isEqualToString:CoreNSArray]){
                            
                            BaseModel *childModel=(BaseModel *)value;
                            
                            [childModel setValue:NSStringFromClass(baseModel.class) forKey:@"pModel"];
                            
                            [childModel setValue:@(baseModel.hostID) forKey:@"pid"];
                            
                            [NSClassFromString(property.type.code) insert:value resBlock:resBlock];

                        }else{
                            
                            if(![self isBasicTypeInNSArray:[self statementForNSArrayProperties][property.name]]){
                                
                                NSArray *modelsArray = (NSArray *)value;
                                [modelsArray enumerateObjectsUsingBlock:^(BaseModel *i, NSUInteger idx, BOOL *stop) {
                                    [i setValue:NSStringFromClass([self class]) forKeyPath:@"pModel"];
                                    [i setValue:@(baseModel.hostID) forKeyPath:@"pid"];
                                }];
                                
                                Class Cls = NSClassFromString([self statementForNSArrayProperties][property.name]);
                                
                                [Cls inserts:modelsArray resBlock:resBlock];
                                
                            }
                        }
                        
                    }
                }
            }
        }];
        
        NSString *fields_sub=[self deleteLastChar:fields];
        NSString *values_sub=[self deleteLastChar:values];
        
        NSString *sql=[NSString stringWithFormat:@"INSERT INTO %@ (%@) VALUES (%@);",[self modelName],fields_sub,values_sub];
        
        
        BOOL insertRes = [CoreFMDB executeUpdate:sql];
        
        if(BaseModelDeBug) {if(!insertRes) NSLog(@"错误：添加对象失败%@",baseModel);};
        if(BaseModelDeBug) NSLog(@"数据插入结束%@",[NSThread currentThread]);

    }];
}


+(void)insert:(id)model resBlock:(void(^)(BOOL res))resBlock newThread:(BOOL)newThread{
    
    if (newThread){
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [self insertAction:model resBlock:resBlock];
        });
    }else{
        [self insertAction:model resBlock:resBlock];
    }
}

+(void)insert:(id)model resBlock:(void(^)(BOOL res))resBlock{
    [self insert:model resBlock:resBlock newThread:YES];
}


+(void)inserts:(NSArray *)models resBlock:(void(^)(BOOL res))resBlock{
    
    if(![self checkTableExists]){
        
        if(BaseModelDeBug)NSLog(@"注意：批量数据插入时，你操作的模型%@在数据库中没有对应的数据表！%@",[self modelName],AutoMsg);
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(AutoTry * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self inserts:models resBlock:resBlock];
        });
        
        return;
    }
    
    if(BaseModelDeBug)NSLog(@"表创建成功，开始批量数据插入！");
    
    [self insertsActon:models resBlock:resBlock];

}

+(void)insertsActon:(NSArray *)models resBlock:(void(^)(BOOL res))resBlock{
    
    if(models == nil || models.count == 0){resBlock(NO);return;}
    
    if(![self checkTableExists]){
        
        if(BaseModelDeBug) NSLog(@"注意：单条数据插入时，你操作的模型%@在数据库中没有对应的数据表！%@",[self modelName],AutoMsg);
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(AutoTry * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self insertsActon:models resBlock:resBlock];
        });
        
        return;
    }
    
    NSOperationQueue *queue = [NSOperationQueue queue];
    
    if(BaseModelDeBug)NSLog(@"批量插入开始%@",[NSThread currentThread]);
    
    for (BaseModel *baseModel in models) {
        
        NSBlockOperation *operation = [NSBlockOperation blockOperationWithBlock:^{
            [self insert:baseModel resBlock:resBlock newThread:NO];ThreadShow(批量插入操作)
        }];
        
        [queue addOperation:operation];
    }
}

@end
