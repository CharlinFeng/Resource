//
//  NSOperationQueue+Queue.h
//  CoreClass
//
//  Created by 成林 on 15/8/30.
//  Copyright (c) 2015年 muxi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSOperationQueue (Queue)


+(instancetype)queue;

@end
